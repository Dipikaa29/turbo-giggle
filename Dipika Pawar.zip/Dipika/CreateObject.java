package Dipika;

public class CreateObject 
{
	void show()    
	{    
	System.out.println("Welcome to javaTpoint");    
	}    
	public static void main(String[] args)   
	{    
	//creating an object using new keyword   
	CreateObject obj = new CreateObject();   
	//invoking method using the object  
	obj.show();    
	}    
}
